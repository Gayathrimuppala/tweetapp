package com.tweetapp.tweet.constants;

public class UserConstants {
	public static final String SECURITY_QUESTION = "What is the name of this APP?";
	
	public static final String ANSWER_FOR_SECURITY_QN = "TweetApp";
}
