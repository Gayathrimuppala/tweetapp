package com.tweetapp.tweet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweet.dao.UserRepository;
import com.tweetapp.tweet.service.KafkaSender;

@RestController
@RequestMapping(value = "kafka/")
public class ApacheKafkaWebController {

	@Autowired
	KafkaSender kafkaSender;

	@Autowired
	private UserRepository userRepo;

	@RequestMapping(value = "user/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getAllUsers() throws IllegalArgumentException {
		kafkaSender.send(userRepo.findAll());
		return "Message sent to the Kafka Successfully";
	}

}
