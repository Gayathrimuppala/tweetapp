package com.tweetapp.tweet.controller;

import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweet.constants.UserConstants;
import com.tweetapp.tweet.dao.UserRepository;
import com.tweetapp.tweet.dto.ForgotPasswordDto;
import com.tweetapp.tweet.dto.UserDto;
import com.tweetapp.tweet.dto.UserLoginDto;
import com.tweetapp.tweet.dto.UserPasswordResetDto;
import com.tweetapp.tweet.dto.userResponseDto;
import com.tweetapp.tweet.service.LoggedUserService;
import com.tweetapp.tweet.service.UserService;

@Controller
@RestController
@RequestMapping("/tweetapp")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private UserService userService;

	@Autowired
	private LoggedUserService loggedUserService;

	@RequestMapping(value = "user", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<userResponseDto> createUser(@Valid @RequestBody final UserDto userRequest)
			throws IllegalArgumentException {

		userResponseDto user = new userResponseDto();

		try {
			if (userService.findUserByEmail(userRequest.getEmail()) != null) {
				user.setErrorMessage("User Already Exists");
				user.setSuccess(false);
//				return new ResponseEntity<userResponseDto>(user, HttpStatus.CONFLICT);
				return new ResponseEntity<userResponseDto>(user, HttpStatus.OK);
			}

			user = userService.createUser(userRequest);
			return new ResponseEntity<userResponseDto>(user, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println("Exception occurred at createUser " + e.getMessage());
			user.setErrorMessage("Exception occurred at createUser");
			return new ResponseEntity<userResponseDto>(user, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "user/all", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List getAllUsers() throws IllegalArgumentException {
		return (List) userRepo.findAll();

	}

	@RequestMapping(value = "user/search/{email}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public UserDto getUserByEmail(@PathVariable String email) {
		return userService.findUserByEmail(email);
	}

	@RequestMapping(value = "user/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<userResponseDto> getUserInfo(@PathVariable Long id) {
		userResponseDto user = new userResponseDto();
		try {
			if (checkIsUserLoggedIn(id)) {
				user = userService.findUserById(id);
				if (!user.isSuccess()) {
					return new ResponseEntity<userResponseDto>(user, HttpStatus.NOT_FOUND);
				}
				user.setLogin(true);
				return new ResponseEntity<userResponseDto>(user, HttpStatus.OK);
			} else {
				user.setErrorMessage("User not authenticated");
				user.setLogin(false);
				return new ResponseEntity<userResponseDto>(user, HttpStatus.UNAUTHORIZED);
			}
		} catch (Exception e) {
			System.out.println("Exception occurred at getUserInfo " + e.getMessage());
			user.setErrorMessage("Exception occurred at getUserInfo");
			user.setLogin(false);
			return new ResponseEntity<userResponseDto>(user, HttpStatus.UNAUTHORIZED);
		}
	}

	@RequestMapping(value = "user/reset", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<userResponseDto> resetPassword(@Valid @RequestBody UserPasswordResetDto passwordResetDto)
			throws IllegalArgumentException {

		userResponseDto status = new userResponseDto();
		try {
			if (checkIsUserLoggedIn(passwordResetDto.getId())) {
				status = userService.resetPassword(passwordResetDto);
				status.setLogin(true);
				return new ResponseEntity<userResponseDto>(status, HttpStatus.OK);
			} else {
				status.setLogin(false);
				status.setErrorMessage("User not authenticated");

				return new ResponseEntity<userResponseDto>(status, HttpStatus.UNAUTHORIZED);
			}
		} catch (Exception e) {
			System.out.println("Exception occurred at resetPassword " + e.getMessage());
			status.setErrorMessage("Exception occurred at resetPassword");
			status.setLogin(false);
			return new ResponseEntity<userResponseDto>(status, HttpStatus.UNAUTHORIZED);
		}
	}

	@RequestMapping(value = "user/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<userResponseDto> userLogin(@Valid @RequestBody UserLoginDto userLoginReq)
			throws IllegalArgumentException {

		userResponseDto user = userService.userLogin(userLoginReq);
		return new ResponseEntity<userResponseDto>(user, HttpStatus.OK);
	}

	@RequestMapping(value = "user/logout/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Boolean> userLogout(@PathVariable Long id) throws IllegalArgumentException {

		boolean user = loggedUserService.logout(id);
		return new ResponseEntity<Boolean>(user, HttpStatus.OK);
	}

	private boolean checkIsUserLoggedIn(Long id) {
		return loggedUserService.findLoggedByUserId(id);
	}

	@RequestMapping(value = "user/forgotPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ForgotPasswordDto> forgotPassword(@Valid @RequestBody ForgotPasswordDto forgotPasswordDto) {
		ForgotPasswordDto forgotPasswordResponse = new ForgotPasswordDto();
		try {
			UserDto user = userService.findUserByEmail(forgotPasswordDto.getEmail());
			forgotPasswordResponse.setSecurityQuestion(UserConstants.SECURITY_QUESTION);
			if (user == null) {
				forgotPasswordResponse.setErrorMessage("User does not exist");
				forgotPasswordResponse.setSuccess(false);
				return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
			}

			if (forgotPasswordDto.getAnswer() != null
					&& !forgotPasswordDto.getAnswer().equalsIgnoreCase(UserConstants.ANSWER_FOR_SECURITY_QN)) {
				forgotPasswordResponse.setErrorMessage("Incorrect answer");
				forgotPasswordResponse.setSuccess(false);
				return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
			}
			forgotPasswordResponse.setMessage("Retrieved Password successfully");
			forgotPasswordResponse.setUserPassword(user.getPassword());
			forgotPasswordResponse.setSuccess(false);
			return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println("Exception occurred at forgotPassword " + e.getMessage());
			forgotPasswordResponse.setErrorMessage("Exception occurred at forgotPassword");
			forgotPasswordResponse.setSuccess(false);
			return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
		}

	}

	@RequestMapping(value = "user/forgotPassword/{email}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ForgotPasswordDto> forgotPassword(@PathVariable() String email) {
		ForgotPasswordDto forgotPasswordResponse = new ForgotPasswordDto();

		try {
			if (userService.findUserByEmail(email) == null) {
				forgotPasswordResponse.setErrorMessage("User does not exist");
				forgotPasswordResponse.setSuccess(false);
				return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
			}
			forgotPasswordResponse.setMessage("Please answer the security question");
			forgotPasswordResponse.setSuccess(true);
			forgotPasswordResponse.setSecurityQuestion(UserConstants.SECURITY_QUESTION);
			return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println("Exception occurred at forgotPassword " + e.getMessage());
			forgotPasswordResponse.setErrorMessage("Exception occurred at forgotPassword");
			forgotPasswordResponse.setSuccess(false);
			return new ResponseEntity<ForgotPasswordDto>(forgotPasswordResponse, HttpStatus.OK);
		}

	}
	@RequestMapping(value = "hello", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String hello()
	{
		return "hello";
	}
	
}
