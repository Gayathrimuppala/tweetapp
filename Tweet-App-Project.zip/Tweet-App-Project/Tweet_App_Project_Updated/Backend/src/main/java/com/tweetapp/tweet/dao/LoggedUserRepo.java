package com.tweetapp.tweet.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.tweet.dto.LoggedUsers;

@Repository
public interface LoggedUserRepo extends JpaRepository<LoggedUsers, Long> {
	LoggedUsers findLoggedUsersByUserId(Long id);
	
	Integer deleteLoggedUsersByUserId(Long id);
}
