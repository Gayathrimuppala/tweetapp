package com.tweetapp.tweet.dto;

public class FieldErrorDTO {
	private String fieldName;

	private String message;

	public FieldErrorDTO(final String fieldName, final String message) {
		this.fieldName = fieldName;
		this.message = message;
	}

	public FieldErrorDTO() {

	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(final String fieldName) {
		this.fieldName = fieldName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(final String message) {
		this.message = message;
	}
}
