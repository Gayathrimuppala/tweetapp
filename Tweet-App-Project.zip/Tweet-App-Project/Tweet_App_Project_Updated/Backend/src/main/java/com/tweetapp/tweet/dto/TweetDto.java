package com.tweetapp.tweet.dto;

public class TweetDto {

	private String firstName;
	private TweetsDto userTweet;

	public TweetsDto getUserTweet() {
		return userTweet;
	}

	public void setUserTweet(TweetsDto userTweet) {
		this.userTweet = userTweet;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public TweetDto() {
	}

	@Override
	public String toString() {
		return "TweetDto [userTweet=" + userTweet + ", firstName=" + firstName + "]";
	}

	public TweetDto(TweetsDto userTweet, String firstName) {
		super();
		this.userTweet = userTweet;
		this.firstName = firstName;
	}

}
