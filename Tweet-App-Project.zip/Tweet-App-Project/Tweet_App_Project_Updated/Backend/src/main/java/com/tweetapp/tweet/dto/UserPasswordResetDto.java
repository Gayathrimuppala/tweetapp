package com.tweetapp.tweet.dto;

import javax.validation.constraints.NotNull;

public class UserPasswordResetDto {

	@NotNull
	private Long id;

	@NotNull
	private String password;

	@NotNull
	private String newPassword;

	public final Long getId() {
		return id;
	}

	public final void setId(Long id) {
		this.id = id;
	}

	public final String getPassword() {
		return password;
	}

	public final void setPassword(String password) {
		this.password = password;
	}

	public final String getNewPassword() {
		return newPassword;
	}

	public final void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public UserPasswordResetDto() {
	}

	public UserPasswordResetDto(@NotNull Long id, @NotNull String password, @NotNull String newPassword) {
		super();
		this.id = id;
		this.password = password;
		this.newPassword = newPassword;
	}

	@Override
	public String toString() {
		return "UserPasswordResetDto [id=" + id + ", password=" + password + ", newPassword=" + newPassword + "]";
	}

}
