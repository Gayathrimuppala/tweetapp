package com.tweetapp.tweet.exception;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.tweetapp.tweet.dto.FieldErrorDTO;
import com.tweetapp.tweet.dto.ValidationErrorDto;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(RuntimeException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public ValidationErrorDto handleRunTimeException(final RuntimeException exception) {
		final ValidationErrorDto errorDto = new ValidationErrorDto();
		errorDto.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		errorDto.setErrorMessage(exception.getMessage());
		return errorDto;
	}

	@ExceptionHandler(IllegalArgumentException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ValidationErrorDto handleIllegalArgumentExceptions(final IllegalArgumentException illegalArgumentException) {
		final ValidationErrorDto errorDto = new ValidationErrorDto();
		errorDto.setHttpStatusCode(HttpStatus.BAD_REQUEST.toString());
		errorDto.setErrorMessage(illegalArgumentException.getMessage());
		return errorDto;
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ValidationErrorDto handleMethodArgumentNotValidException(final MethodArgumentNotValidException exception) {
		final ValidationErrorDto errorDto = new ValidationErrorDto();
		errorDto.setHttpStatusCode(HttpStatus.BAD_REQUEST.toString());
		errorDto.setErrorMessage(exception.getMessage());

		for (final FieldError error : exception.getBindingResult().getFieldErrors()) {
			errorDto.addFieldErrors(new FieldErrorDTO(error.getField(), error.getDefaultMessage()));
		}
		for (final ObjectError error : exception.getBindingResult().getGlobalErrors()) {
			errorDto.addFieldErrors(new FieldErrorDTO(error.getObjectName(), error.getDefaultMessage()));
		}
		return errorDto;
	}

	@ExceptionHandler(ServiceException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public ValidationErrorDto generalException(final Exception exception) {
		final ValidationErrorDto errorDto = new ValidationErrorDto();
		errorDto.setHttpStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		errorDto.setErrorMessage(exception.getMessage());
		return errorDto;
	}
}
