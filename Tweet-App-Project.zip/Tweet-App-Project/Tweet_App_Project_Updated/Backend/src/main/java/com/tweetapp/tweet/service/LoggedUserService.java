package com.tweetapp.tweet.service;

import com.tweetapp.tweet.exception.ServiceException;

public interface LoggedUserService {
	boolean findLoggedByUserId(Long id) throws ServiceException;
	
	boolean save(Long id) throws ServiceException;
	
	boolean logout(Long id) throws ServiceException;
}
