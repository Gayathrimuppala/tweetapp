package com.tweetapp.tweet.service;

import com.tweetapp.tweet.dto.TweetsDto;
import com.tweetapp.tweet.dto.TweetsResponseDto;
import com.tweetapp.tweet.dto.userResponseDto;
import com.tweetapp.tweet.exception.ServiceException;

public interface TweetService {

	userResponseDto postTweet(TweetsDto tweetsDto) throws ServiceException;

	TweetsResponseDto getAllTweets() throws ServiceException;

}
