package com.tweetapp.tweet.service;


import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.tweetapp.tweet.dao.UserRepository;
import com.tweetapp.tweet.dto.UserDto;
import com.tweetapp.tweet.dto.UserLoginDto;
import com.tweetapp.tweet.dto.UserPasswordResetDto;
import com.tweetapp.tweet.dto.userResponseDto;
import com.tweetapp.tweet.exception.ServiceException;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private LoggedUserService loggedUserService;

	@Override
	public UserDto findUserByEmail(String email) throws ServiceException {
		try {
			List<UserDto> userExist = userRepo.findByEmail(email);
			if (!CollectionUtils.isEmpty(userExist)) {
				return userExist.get(0);
			}
			return null;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}
	}

	@Override
	public userResponseDto createUser(UserDto userRequest) throws ServiceException {
		try {
			UserDto createdUser = userRepo.save(userRequest);
			userResponseDto user = new userResponseDto();
			setUserResponse(user, createdUser);
			;
			user.setMessage("User Created");
			return user;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}
	}

	@Override
	public userResponseDto findUserById(Long id) throws ServiceException {
		try {
			Optional<UserDto> existingUser = userRepo.findById(id);
			userResponseDto user = new userResponseDto();
			if (!existingUser.isPresent()) {
				user.setErrorMessage("Cannot find user");
				user.setSuccess(false);
				return user;
			}
			setUserResponse(user, existingUser.get());
			user.setMessage("Fetched User successfully");
			return user;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}
	}

	private void setUserResponse(userResponseDto user, UserDto userDto) {
		user.setId(userDto.getId());
		user.setFirstName(userDto.getFirstName());
		user.setEmail(userDto.getEmail());
		user.setTweets(userDto.getTweets());
		user.setSuccess(true);
	}

	@Override
	public userResponseDto resetPassword(@Valid UserPasswordResetDto passwordResetDto) throws ServiceException {

		try {
			Optional<UserDto> existingUser = userRepo.findById(passwordResetDto.getId());
			userResponseDto user = new userResponseDto();
			if (!existingUser.isPresent()) {
				user.setErrorMessage("Cannot find user");
				user.setSuccess(false);
				return user;
			}

			if (!existingUser.get().getPassword().equals(passwordResetDto.getPassword())) {
				user.setId(existingUser.get().getId());
				user.setErrorMessage("Password does not match with our records");
				user.setSuccess(false);
				return user;
			}

			existingUser.get().setPassword(passwordResetDto.getNewPassword());
			userRepo.save(existingUser.get());
			user.setId(existingUser.get().getId());
			user.setMessage("Password changed successfully");
			user.setSuccess(true);
			return user;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}

	}

	@Override
	public userResponseDto userLogin(UserLoginDto userLoginReq) throws ServiceException {
		try {
			userResponseDto user = new userResponseDto();
			List<UserDto> userExist = userRepo.findByEmail(userLoginReq.getEmail());
			user.setLogin(false);
			user.setSuccess(false);
			if (CollectionUtils.isEmpty(userExist)) {
				user.setErrorMessage("There is no account linked with this email");
				return user;
			}

			if (!userLoginReq.getPassword().equals(userExist.get(0).getPassword())) {
				user.setErrorMessage("Incorrect password");
				return user;
			}

			setUserResponse(user, userExist.get(0));
			user.setMessage("Logged in");
			user.setLogin(true);
			loggedUserService.save(userExist.get(0).getId());
			return user;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}

	}

}
