import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule, } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AuthGuard } from './helper/auth.guard';

import { LayoutComponent } from './layout/layout.component';
import { LayoutModule } from './layout/layout.module';
import { LoginPageComponent } from './layout/login-page/login-page.component';
import { RegistrationPageComponent } from './layout/registration-page/registration-page.component';
import { ForgotPasswordComponent } from './layout/forgot-password/forgot-password.component';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: LoginPageComponent,
    pathMatch: 'full'
  },
  {
    path: 'registrationpage',
    component: RegistrationPageComponent,
    pathMatch: 'full'
  },
  {
    path: 'forgotpassword',
    component: ForgotPasswordComponent,
    pathMatch: 'full'
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        loadChildren: './layout/layout.module#LayoutModule'
      },
    ],
    canActivate: [AuthGuard]
  },

];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],


})

export class AppRoutingModule { }
