import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatTableModule, MatFormFieldModule, MatDialog } from '@angular/material';
import { MatDialogModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutComponent } from './layout/layout.component';
import { LoginPageComponent } from './layout/login-page/login-page.component';
import { RegistrationPageComponent } from './layout/registration-page/registration-page.component';
import { ForgotPasswordComponent } from './layout/forgot-password/forgot-password.component';

import { ChangePasswordComponent } from './layout/change-password/change-password.component';
import { NavbarComponent } from './layout/navbar/navbar.component';
import { UsersComponent } from './layout/users/users.component';
import { TweetsComponent } from './layout/tweets/tweets.component';
import { MyTweetsComponent } from './layout/my-tweets/my-tweets.component';


@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    LoginPageComponent,
    RegistrationPageComponent,
    ChangePasswordComponent,
    NavbarComponent,
    UsersComponent,
    TweetsComponent,
    ForgotPasswordComponent,
    MyTweetsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    RouterModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatDialogModule,
    BrowserAnimationsModule

  ],
  exports: [
    NavbarComponent,
  ],
  providers: [DatePipe, MatDialog],
  bootstrap: [AppComponent]
})
export class AppModule { }
