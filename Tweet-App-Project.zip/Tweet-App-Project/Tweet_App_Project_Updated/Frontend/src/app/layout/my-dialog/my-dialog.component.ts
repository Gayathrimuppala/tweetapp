import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

import { LoginService } from '../../services/login.service';
const USER_KEY = "userObject";
@HostListener('window:keydown', ['$event'])
@Component({
  selector: 'app-my-dialog',
  templateUrl: './my-dialog.component.html',
  styleUrls: ['./my-dialog.component.css'],
  providers: [LoginService]
})
export class MyDialogComponent implements OnInit {
  displayConfirmBtn: boolean = false;
  UserDetails: any;
  constructor(public dialogRef: MatDialogRef<MyDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public sanitizer: DomSanitizer,
    private _LoginService: LoginService) { }


  ngOnInit() {
    this.UserDetails = JSON.parse(localStorage.getItem(USER_KEY));
  }

  onKeydown($event: KeyboardEvent) {
    if ($event.keyCode == 13 && this.displayConfirmBtn == false) {
      // Enter
      this.dialogRef.close();
    };
  }

  stay_user_click() {
    localStorage.setItem("refreshTokenCall", "yes");
  }

  logout_user_click() {
    this._LoginService.LogoutUser(this.UserDetails.id);
  }
}
