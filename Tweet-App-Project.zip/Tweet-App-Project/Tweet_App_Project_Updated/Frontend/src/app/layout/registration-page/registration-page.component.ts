import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


import { RegisterUser, UserDetails, ErrorRegisterUser } from '../../models/login-model';
import { DatePipe } from '@angular/common';

import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-registration-page',
  templateUrl: './registration-page.component.html',
  styleUrls: ['./registration-page.component.css'],
  providers: [LoginService]
})
export class RegistrationPageComponent implements OnInit {
  constructor(public router: Router,
    private _loginServices: LoginService,
    public datePipe: DatePipe) { }
  public UserDetails: UserDetails = new UserDetails();
  public RegisterUser: RegisterUser = new RegisterUser();
  public ErrorRegisterUser: ErrorRegisterUser = new ErrorRegisterUser();


  ngOnInit() {
    this.RegisterUser.firstName = "";
    this.RegisterUser.lastName = "";
    this.RegisterUser.dob = "";
    this.RegisterUser.email = "";
    this.RegisterUser.gender = "Male";
    this.RegisterUser.password = "";
    this.ErrorRegisterUser.error = "";
  }
  register_btn_click() {
    if ((this.RegisterUser.firstName == "" || this.RegisterUser.firstName == undefined || this.RegisterUser.firstName == null)) {
      this.ErrorRegisterUser.error = 'Please enter First Name';
      return false;
    }
    if ((this.RegisterUser.lastName == "" || this.RegisterUser.lastName == undefined || this.RegisterUser.lastName == null)) {
      this.ErrorRegisterUser.error = 'Please enter Last Name';
      return false;
    }
    if ((this.RegisterUser.dob == "" || this.RegisterUser.dob == undefined || this.RegisterUser.dob == null)) {
      this.ErrorRegisterUser.error = 'Please select Date of Birth';
      return false;
    }
    if ((this.RegisterUser.email == "" || this.RegisterUser.email == undefined || this.RegisterUser.email == null)) {
      this.ErrorRegisterUser.error = 'Please enter Email Id';
      return false;
    }
    if ((this.RegisterUser.password == "" || this.RegisterUser.password == undefined || this.RegisterUser.password == null)) {
      this.ErrorRegisterUser.error = 'Please enter password';
      return false;
    }
    if (this.RegisterUser.firstName != "" &&
      this.RegisterUser.lastName != "" &&
      this.RegisterUser.dob != "" &&
      this.RegisterUser.email != "" &&
      this.RegisterUser.password != ""
    ) {
      this.registerUser(this.RegisterUser);
    }

  }
  registerUser(registerUser: any) {
    try {
      registerUser.dob = this.datePipe.transform(this.RegisterUser.dob, 'yyyy-MM-dd');
      this._loginServices.RegisterUser(registerUser).subscribe((data: any) => {


        this.UserDetails.email = data.email;
        this.UserDetails.firstName = data.firstName;
        this.UserDetails.tweets = data.tweets;
        this.UserDetails.success = data.success
        if (this.UserDetails.success) {
          alert("User Registered Successfully");
          this.router.navigate(['login']);
        }
        else {
          this.ErrorRegisterUser.error = data.errorMessage;
        }

      },
        (err) => {
          this.ngOnInit();
          alert(err.message);
          console.log(err);
        });
    }
    catch (error) {

    }
  }
}
