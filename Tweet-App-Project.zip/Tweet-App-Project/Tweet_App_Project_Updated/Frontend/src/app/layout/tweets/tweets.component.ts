import { Component, OnInit } from '@angular/core';

import { AllTweet } from '../../models/tweet-model';
import { TweetsService } from '../../services/tweets.service';

const USER_KEY = "userObject";
@Component({
  selector: 'app-tweets',
  templateUrl: './tweets.component.html',
  styleUrls: ['./tweets.component.css'],
  providers: [TweetsService]
})
export class TweetsComponent implements OnInit {

  UserDetails: any;
  tweetsAvailable: boolean = false;
  _AllTweet: AllTweet = new AllTweet();
  constructor(public _TweetsService: TweetsService) { }

  ngOnInit() {
    this.UserDetails = JSON.parse(localStorage.getItem(USER_KEY));
    this.getAllUsersTweets();
  }
  getAllUsersTweets() {
    this._TweetsService.GetAllUserTweets(this.UserDetails.id).subscribe(data => {

      this._AllTweet.tweets = data.tweets;
      if (this._AllTweet.tweets.length == 0) {
        this.tweetsAvailable = false;
      }
      else {
        this.tweetsAvailable = true;
        for (var i = 0; i < this._AllTweet.tweets.length; i++) {
          this._AllTweet.tweets[i].userTweet.tweet = "This is my first Tweet";
        }
      }

    },
      (err) => {
        this.ngOnInit();
        alert(err.message);
        console.log(err);
      });
  }
}
