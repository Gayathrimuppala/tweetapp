import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  isLoggedIn$ = new BehaviorSubject<boolean>(false);
  UserDetails:any;



  setLogin(loginStatus: boolean): void {
    this.isLoggedIn$.next(loginStatus);
  }

  getLogin(): Observable<boolean> {
    return this.isLoggedIn$.asObservable();
  }



  getUserId(): number {

    this.UserDetails  =  JSON.parse(localStorage.getItem("userObject"));
    return this.UserDetails.id;
  }

}
