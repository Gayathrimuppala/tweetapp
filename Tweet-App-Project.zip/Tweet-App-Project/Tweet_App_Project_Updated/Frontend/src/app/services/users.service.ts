import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from './../../environments/environment';





@Injectable({ providedIn: 'root' })
export class UserService {
  public user: Observable<any>;


  constructor(
    public router: Router,
    public http: HttpClient,
  ) { }


  public getAllUsers(): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/all");
  }

  public searchUser(email:string): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/search/"+email);
  }
}
