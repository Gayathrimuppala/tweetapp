package com.tweetapp.tweet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.tweet.dto.TweetsDto;
import com.tweetapp.tweet.dto.TweetsResponseDto;
import com.tweetapp.tweet.dto.userResponseDto;
import com.tweetapp.tweet.service.LoggedUserService;
import com.tweetapp.tweet.service.TweetService;

@RestController
@RequestMapping("/tweet")
@CrossOrigin(origins = "*")
public class TweetsController {

	@Autowired
	private TweetService tweetService;

	@Autowired
	private LoggedUserService loggedUserService;

	@RequestMapping(value = "post", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<userResponseDto> postTweet(@RequestBody TweetsDto tweetsDto) {
		userResponseDto tweets = new userResponseDto();
		try {

			/*
			 * if (checkIsUserLoggedIn(tweetsDto.getUser().getId())) { tweets =
			 * tweetService.postTweet(tweetsDto); if (!tweets.isSuccess()) { return new
			 * ResponseEntity<userResponseDto>(tweets, HttpStatus.NOT_FOUND); }
			 * tweets.setLogin(true); return new ResponseEntity<userResponseDto>(tweets,
			 * HttpStatus.OK); } else { tweets.setErrorMessage("User not authenticated");
			 * tweets.setLogin(false); return new ResponseEntity<userResponseDto>(tweets,
			 * HttpStatus.UNAUTHORIZED); }
			 */
		
			tweets = tweetService.postTweet(tweetsDto);
			tweets.setLogin(true);
			return new ResponseEntity<userResponseDto>(tweets, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println("Exception occurred at postTweet " + e.getMessage());
			tweets.setErrorMessage("Exception occurred at postTweet");
			tweets.setLogin(false);
			return new ResponseEntity<userResponseDto>(tweets, HttpStatus.UNAUTHORIZED);
		}

	}

	@RequestMapping(value = "tweets/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TweetsResponseDto> getAllTweets(@PathVariable Long id) {
		TweetsResponseDto tweets = new TweetsResponseDto();
		try {

			/*
			 * if (checkIsUserLoggedIn(id)) { return new
			 * ResponseEntity<TweetsResponseDto>(tweetService.getAllTweets(),
			 * HttpStatus.OK); } else { tweets.setErrorMessage("User not authenticated");
			 * tweets.setLogin(false); return new ResponseEntity<TweetsResponseDto>(tweets,
			 * HttpStatus.UNAUTHORIZED); }
			 */

			return new ResponseEntity<TweetsResponseDto>(tweetService.getAllTweets(), HttpStatus.OK);
		} catch (Exception e) {
			System.out.println("Exception occurred at getAllTweets " + e.getMessage());
			tweets.setErrorMessage("Exception occurred at getAllTweets ");
			tweets.setLogin(false);
			return new ResponseEntity<TweetsResponseDto>(tweets, HttpStatus.UNAUTHORIZED);
		}
	}

	private boolean checkIsUserLoggedIn(Long id) {
		return loggedUserService.findLoggedByUserId(id);
	}
}
