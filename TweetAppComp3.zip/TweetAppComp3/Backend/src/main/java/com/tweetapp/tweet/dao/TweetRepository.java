package com.tweetapp.tweet.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.tweet.dto.TweetsDto;

@Repository
public interface TweetRepository extends JpaRepository<TweetsDto, Long> {

}
