package com.tweetapp.tweet.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.tweet.dto.UserDto;

@Repository
public interface UserRepository extends JpaRepository<UserDto, Long> {

	List<UserDto> findByEmail(String email);
	
}
