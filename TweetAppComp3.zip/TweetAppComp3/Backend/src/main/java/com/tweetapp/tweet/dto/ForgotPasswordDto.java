package com.tweetapp.tweet.dto;

import javax.validation.constraints.NotNull;

public class ForgotPasswordDto {

	@NotNull(message = "Please enter your email id")
	private String email;

	private String securityQuestion;

	@NotNull(message = "Please enter answer for security question, eg: TWEET APP")
	private String answer;

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	private String message;

	private String errorMessage;

	private String userPassword;

	private boolean success;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public ForgotPasswordDto() {

	}

	public ForgotPasswordDto(String email, String securityQuestion, String message, String errorMessage,
			String userPassword, boolean success, String answer) {
		super();
		this.email = email;
		this.securityQuestion = securityQuestion;
		this.message = message;
		this.errorMessage = errorMessage;
		this.userPassword = userPassword;
		this.success = success;
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "ForgotPasswordDto [email=" + email + ", securityQuestion=" + securityQuestion + ", message=" + message
				+ ", errorMessage=" + errorMessage + ", userPassword=" + userPassword + ", success=" + success + "]";
	}

}
