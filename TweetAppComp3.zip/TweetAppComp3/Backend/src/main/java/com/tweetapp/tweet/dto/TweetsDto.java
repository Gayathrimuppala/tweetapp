package com.tweetapp.tweet.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "user_tweets")
public class TweetsDto {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String tweet;

	@ManyToOne(cascade = CascadeType.ALL)
	@JsonBackReference
	private UserDto user;

	public  String getTweet() {
		return tweet;
	}

	public  void setTweet(String tweet) {
		this.tweet = tweet;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public  UserDto getUser() {
		return user;
	}

	public  void setUser(UserDto user) {
		this.user = user;
	}

	public TweetsDto() {

	}

	public TweetsDto(Long id, String tweet, UserDto user) {
		this.id = id;
		this.tweet = tweet;
		this.user = user;
	}

	@Override
	public String toString() {
		return "TweetsDto [id=" + id + ", tweet=" + tweet + "]";
	}

}
