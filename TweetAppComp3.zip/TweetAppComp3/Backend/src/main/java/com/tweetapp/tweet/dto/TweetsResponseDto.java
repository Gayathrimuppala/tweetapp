package com.tweetapp.tweet.dto;

import java.util.List;

public class TweetsResponseDto {

	private boolean success;
	private String message;
	private String errorMessage;
	private List<TweetDto> tweets;
	private boolean login;

	public boolean isLogin() {
		return login;
	}

	public void setLogin(boolean login) {
		this.login = login;
	}

	public final List<TweetDto> getTweets() {
		return tweets;
	}

	public final void setTweets(List<TweetDto> tweets) {
		this.tweets = tweets;
	}

	public final boolean isSuccess() {
		return success;
	}

	public final void setSuccess(boolean success) {
		this.success = success;
	}

	public final String getMessage() {
		return message;
	}

	public final void setMessage(String message) {
		this.message = message;
	}

	public final String getErrorMessage() {
		return errorMessage;
	}

	public final void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public TweetsResponseDto() {

	}

	public TweetsResponseDto(List<TweetDto> tweets, boolean success, String message, String errorMessage, boolean login) {
		this.tweets = tweets;
		this.success = success;
		this.message = message;
		this.errorMessage = errorMessage;
		this.login = login;
	}

	@Override
	public String toString() {
		return "TweetsResponseDto [tweets=" + tweets + ", success=" + success + ", message=" + message + ", errorMessage="
				+ errorMessage + "]";
	}

}
