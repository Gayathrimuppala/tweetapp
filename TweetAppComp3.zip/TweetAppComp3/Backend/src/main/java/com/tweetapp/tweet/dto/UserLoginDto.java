package com.tweetapp.tweet.dto;

import javax.validation.constraints.NotNull;

public class UserLoginDto {

	@NotNull(message = "Please provide email id, eg: joe@tweetapp.com")
	private String email;
	
	@NotNull(message = "Please provide password")
	private String password;

	public final String getEmail() {
		return email;
	}

	public final void setEmail(String email) {
		this.email = email;
	}

	public final String getPassword() {
		return password;
	}

	public final void setPassword(String password) {
		this.password = password;
	}

	

}
