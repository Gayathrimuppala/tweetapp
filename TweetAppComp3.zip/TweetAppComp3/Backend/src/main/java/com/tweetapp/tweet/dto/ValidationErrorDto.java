package com.tweetapp.tweet.dto;

import java.util.ArrayList;
import java.util.List;


public class ValidationErrorDto {
	private String httpStatusCode;

	private String errorMessage;

	private List<FieldErrorDTO> fieldErrors;

	public String getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(String httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<FieldErrorDTO> getFieldErrors() {
		return fieldErrors;
	}

	public void setFieldErrors(List<FieldErrorDTO> fieldErrors) {
		this.fieldErrors = fieldErrors;
	}

	public ValidationErrorDto() {
	}

	public void addFieldErrors(FieldErrorDTO fieldErrDto) {
		if(this.fieldErrors == null) {
			this.fieldErrors = new ArrayList<>();
		}
		this.fieldErrors.add(fieldErrDto);
	}
	
	public ValidationErrorDto(String httpStatusCode, String errorMessage, List<FieldErrorDTO> fieldErrors) {
		super();
		this.httpStatusCode = httpStatusCode;
		this.errorMessage = errorMessage;
		this.fieldErrors = fieldErrors;
	}

	@Override
	public String toString() {
		return "ValidationErrorDto [httpStatusCode=" + httpStatusCode + ", errorMessage=" + errorMessage
				+ ", fieldErrors=" + fieldErrors + "]";
	}

}
