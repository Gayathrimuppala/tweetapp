package com.tweetapp.tweet.dto;

import java.util.List;

public class userResponseDto {

	private Long id;
	private String firstName;
	private String email;
	private String message;
	private List<TweetsDto> tweets;
	private String errorMessage;
	private boolean success;
	private boolean login;

	public boolean isLogin() {
		return login;
	}

	public void setLogin(boolean login) {
		this.login = login;
	}

	public final List<TweetsDto> getTweets() {
		return tweets;
	}

	public final void setTweets(List<TweetsDto> tweets) {
		this.tweets = tweets;
	}

	public final boolean isSuccess() {
		return success;
	}

	public final void setSuccess(boolean success) {
		this.success = success;
	}

	public final Long getId() {
		return id;
	}

	public final void setId(Long id) {
		this.id = id;
	}

	public final String getFirstName() {
		return firstName;
	}

	public final void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public final String getEmail() {
		return email;
	}

	public final void setEmail(String email) {
		this.email = email;
	}

	public final String getMessage() {
		return message;
	}

	public final void setMessage(String message) {
		this.message = message;
	}

	public final String getErrorMessage() {
		return errorMessage;
	}

	public final void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public userResponseDto() {

	}

	public userResponseDto(Long id, String firstName, String email, String message, String errorMessage,
			boolean success, List<TweetsDto> tweets, boolean login) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.email = email;
		this.message = message;
		this.errorMessage = errorMessage;
		this.success = success;
		this.tweets = tweets;
		this.login = login;
	}

	@Override
	public String toString() {
		return "userResponseDto [id=" + id + ", firstName=" + firstName + ", email=" + email + ", message=" + message
				+ ", tweets=" + tweets + ", errorMessage=" + errorMessage + ", success=" + success + "]";
	}

}
