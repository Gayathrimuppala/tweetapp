package com.tweetapp.tweet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.tweetapp.tweet.dto.UserDto;

@Service
public class KafkaSender {
	
	@Autowired
	private KafkaTemplate<String, List<UserDto>> kafkaTemplate;
	
	String kafkaTopic = "Revathi";
	
	public void send(List<UserDto> list ) {
	    
	    kafkaTemplate.send(kafkaTopic, list);
	}
}