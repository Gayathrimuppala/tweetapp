package com.tweetapp.tweet.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.tweet.dao.LoggedUserRepo;
import com.tweetapp.tweet.dto.LoggedUsers;
import com.tweetapp.tweet.exception.ServiceException;

@Service
public class LoggedUserServiceImpl implements LoggedUserService {

	@Autowired
	private LoggedUserRepo loggedUserRepo;

	@Override
	public boolean findLoggedByUserId(Long id) throws ServiceException {
		try {
			LoggedUsers isLoggedIn = loggedUserRepo.findLoggedUsersByUserId(id);
			if (isLoggedIn != null) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	@Override
	public boolean save(Long id) throws ServiceException {
		try {
			LoggedUsers isUserLoggedIn = loggedUserRepo.findLoggedUsersByUserId(id);
			if (isUserLoggedIn != null) {
				return true;
			} else {
				LoggedUsers user = new LoggedUsers();
				user.setUserId(id);
				LoggedUsers userLogged = loggedUserRepo.save(user);
				if (userLogged != null) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	@Override
	@Transactional
	public boolean logout(Long id) throws ServiceException {
		loggedUserRepo.deleteLoggedUsersByUserId(id);
		return true;
	}

}
