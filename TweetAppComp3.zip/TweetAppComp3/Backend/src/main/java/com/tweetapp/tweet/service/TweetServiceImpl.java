package com.tweetapp.tweet.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.tweetapp.tweet.dao.TweetRepository;
import com.tweetapp.tweet.dao.UserRepository;
import com.tweetapp.tweet.dto.TweetDto;
import com.tweetapp.tweet.dto.TweetsDto;
import com.tweetapp.tweet.dto.TweetsResponseDto;
import com.tweetapp.tweet.dto.UserDto;
import com.tweetapp.tweet.dto.userResponseDto;
import com.tweetapp.tweet.exception.ServiceException;

@Service
public class TweetServiceImpl implements TweetService {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private TweetRepository tweetRepo;

	@Override
	public userResponseDto postTweet(TweetsDto tweetsDto) throws ServiceException {

		try {
			userResponseDto userResponseDto = new userResponseDto();
			Optional<UserDto> user = userRepo.findById(tweetsDto.getUser().getId());

			if (!user.isPresent()) {
				userResponseDto.setErrorMessage("Cannot find User");
				userResponseDto.setSuccess(false);
				return userResponseDto;
			}

			tweetsDto.setUser(user.get());
			tweetRepo.save(tweetsDto);
			userResponseDto.setTweets(user.get().getTweets());
			userResponseDto.setId(user.get().getId());
			userResponseDto.setEmail(user.get().getEmail());
			userResponseDto.setFirstName(user.get().getFirstName());
			userResponseDto.setMessage("Posted a tweet");
			userResponseDto.setSuccess(true);
			return userResponseDto;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}

	}

	private List<TweetDto> organizeTweets(List<TweetsDto> tweets) {
		List<TweetDto> tweetDto = new ArrayList<>();
		tweets.forEach(tweet -> {
			TweetDto userTweet = new TweetDto();
			userTweet.setUserTweet(tweet);
			userTweet.setFirstName(tweet.getUser().getFirstName());
			tweetDto.add(userTweet);
		});
		return tweetDto;
	}

	@Override
	public TweetsResponseDto getAllTweets() throws ServiceException {
		try {
			TweetsResponseDto tweetResponse = new TweetsResponseDto();
			List<TweetsDto> tweets = tweetRepo.findAll();
			tweetResponse.setTweets(organizeTweets(tweets));
			
			if (CollectionUtils.isEmpty(tweets)) {
				tweetResponse.setMessage("No Tweets found in system");
			} else {
				tweetResponse.setMessage("Retrieved all Tweets");
			}
			tweetResponse.setSuccess(true);
			tweetResponse.setLogin(true);
			return tweetResponse;
		} catch (PersistenceException e) {
			throw new ServiceException(e);
		}

	}

}
