package com.tweetapp.tweet.service;

import javax.validation.Valid;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.tweetapp.tweet.dto.UserDto;
import com.tweetapp.tweet.dto.UserLoginDto;
import com.tweetapp.tweet.dto.UserPasswordResetDto;
import com.tweetapp.tweet.dto.userResponseDto;
import com.tweetapp.tweet.exception.ServiceException;

public interface UserService extends UserDetailsService{

	UserDto findUserByEmail(String email) throws ServiceException;

	userResponseDto createUser(UserDto userRequest) throws ServiceException;

	userResponseDto findUserById(Long id) throws ServiceException;

	userResponseDto resetPassword(@Valid UserPasswordResetDto passwordResetDto) throws ServiceException;

	userResponseDto userLogin(UserLoginDto userLoginReq) throws ServiceException;
	UserDetails loadUserByUsername(String userName) throws ServiceException;

	

}
