import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ChangePassword, ErrorChangePassword } from '../../models/login-model';
import { LoginService } from '../../services/login.service';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
  providers: [LoginService]
})
export class ChangePasswordComponent implements OnInit {
  constructor(public router: Router,
    private _loginServices: LoginService) { }

  id: any;
  changePassword: ChangePassword = new ChangePassword();
  errorChangePassword: ErrorChangePassword = new ErrorChangePassword();


  ngOnInit() {
    this.id = localStorage.getItem("id");
    this.errorChangePassword.errormessage = "";
    this.changePassword.password = "";
    this.changePassword.newPassword = "";

  }
  change_password_btn_click() {
    if (this.changePassword.password == null || this.changePassword.password == "" || this.changePassword.password == undefined) {
      this.errorChangePassword.errormessage = "Please enter Password";
    }
    else if (this.changePassword.newPassword == null || this.changePassword.newPassword == "" || this.changePassword.newPassword == undefined) {
      this.errorChangePassword.errormessage = "Please enter New Password";
    }
    else if (this.changePassword.password == this.changePassword.newPassword) {
      this.errorChangePassword.errormessage = "Both Passwords are same...Try different New Password!";
    }
    else {
      this.changePassword.id = Number(this.id);
      this._loginServices.ChangePassword(this.changePassword).subscribe((data: any) => {
        if (data.success) {
          alert(data.message)
          this.router.navigate(['tweets']);
        }
        else {
          this.errorChangePassword.errormessage = data.errorMessage;
        }
      },
        (err) => {
          this.ngOnInit();
          alert(err.message);
        });
    }

  }
  cancel_btn_click() {
    this.router.navigate(['tweets']);
  }

}
