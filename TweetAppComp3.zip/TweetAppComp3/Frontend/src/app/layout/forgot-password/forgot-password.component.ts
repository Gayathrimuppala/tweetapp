import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ForgotPasswordDetails } from '../../models/users-model';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
  providers: [LoginService]
})
export class ForgotPasswordComponent implements OnInit {
  constructor(public _LoginService: LoginService,
    public router: Router) { }
  email: string;
  error: string;
  forgotPassword_template: boolean = false;
  ForgotPasswordDetails: ForgotPasswordDetails = new ForgotPasswordDetails();

  ngOnInit() {
    this.error = "";
    this.forgotPassword_template = true;
  }
  forgot_password_btn_click() {
    if (this.email == "" || this.email == undefined || this.email == null) {
      this.error = "Please enter Email Id";
      return false;
    }
    else {
      this._LoginService.getSecurityQuestion(this.email).subscribe(data => {
        if(data.success)
        {
          this.forgotPassword_template = false;
          this.ForgotPasswordDetails = data;
          this.error = data.errorMessage;
        }
        else
        {
          this.forgotPassword_template = true;
          this.ForgotPasswordDetails = data;
          this.error = data.errorMessage;
        }
      },
        (err) => {
          alert(err.message);
          
        }
      );
    }

  }
  forgot_password() {
    if(this.ForgotPasswordDetails.answer == "" || this.ForgotPasswordDetails.answer == undefined || this.ForgotPasswordDetails.answer == null)
    {
      this.error = "Please enter Answer";
      return false;
    }
    else if(this.ForgotPasswordDetails.password == "" || this.ForgotPasswordDetails.password == undefined || this.ForgotPasswordDetails.password == null)
    {
      this.error = "Please enter New Password";
      return false;
    }
    else
    {
      this.ForgotPasswordDetails.email = this.email;
      this._LoginService.forgotPassword(this.ForgotPasswordDetails).subscribe(data => {
        if(data.errorMessage == null)
        {
          alert(data.message);
          this.router.navigate(['login']);
        }
        else
        {
          this.error = data.errorMessage;
        }

      },
        (err) => {
          alert(err.message);
        }
      );
    }

  }
  cancel_btn_click()
  {
    this.router.navigate(['login']);
  }
  forgot_cancel_btn_click()
  {
    this.router.navigate(['login']);
  }
}
