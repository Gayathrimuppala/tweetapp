import { Routes } from '@angular/router';

import { TweetsComponent } from '../../app/layout/tweets/tweets.component';
import { ChangePasswordComponent }  from '../../app/layout/change-password/change-password.component';
import { UsersComponent } from '../../app/layout/users/users.component';
import { MyTweetsComponent } from '../../app/layout/my-tweets/my-tweets.component';

export const LayoutRoutes: Routes = [

    { path: 'tweets', component: TweetsComponent },
    { path: 'resetpassword',component : ChangePasswordComponent},
    { path : 'users',component : UsersComponent},
    {
        path :'mytweets', component:MyTweetsComponent
    }
];