import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticateUser, ErrorAuthenticateUser, UserDetails } from '../../models/login-model';
import { LoginService } from '../../services/login.service';


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css'],
  providers: [LoginService]
})

export class LoginPageComponent implements OnInit {


  public AuthenticateUser: AuthenticateUser = new AuthenticateUser();
  public ErrorAuthenticateUser: ErrorAuthenticateUser = new ErrorAuthenticateUser();
  public UserDetails: UserDetails = new UserDetails();


  constructor(public router: Router,
    private _loginServices: LoginService
  ) { }


  ngOnInit() {
    this.ErrorAuthenticateUser.errorPassword = "";
  }


  login_btn_click() {
    if ((this.AuthenticateUser.email == "" || this.AuthenticateUser.email == undefined || this.AuthenticateUser.email == null) && (this.AuthenticateUser.password == "" || this.AuthenticateUser.password == undefined || this.AuthenticateUser.password == null)) {
      this.ErrorAuthenticateUser.errorPassword = "Enter User Id and Password";
      return false;
    }
    else if (this.AuthenticateUser.email == "" || this.AuthenticateUser.email == undefined || this.AuthenticateUser.email == null) {
      this.ErrorAuthenticateUser.errorPassword = "Enter User Id";
      return false;
    }
    else if (this.AuthenticateUser.password == "" || this.AuthenticateUser.password == undefined || this.AuthenticateUser.password == null) {
      this.ErrorAuthenticateUser.errorPassword = "Enter Password";
      return false;
    }
    else if ((this.AuthenticateUser.email != "" || this.AuthenticateUser.email != undefined || this.AuthenticateUser.email != null) && (this.AuthenticateUser.password != "" || this.AuthenticateUser.password != undefined || this.AuthenticateUser.password != null)) {
      this.ErrorAuthenticateUser.errorEmailId = "";
      this.ErrorAuthenticateUser.errorPassword = "";
      this.authenticateUser(this.AuthenticateUser.email, this.AuthenticateUser.password);
    }
  }

  authenticateUser(_email: string, _password: string) {
    if (_email != null && _password != null) {
      this.AuthenticateUser.email = _email;
      this.AuthenticateUser.password = _password;
      try {
        this._loginServices.AuthenticateUser(this.AuthenticateUser).subscribe((data) => {
          console.log(data)
          if (data.status == 200) {
            localStorage.setItem("response", String(data.status))
            localStorage.setItem("token", data.headers.get('token'));
            localStorage.setItem("id", data.headers.get('id'))
            this.router.navigate(['tweets'])
          }
          else {
            this.router.navigate(['login'])
          }

        })
      }
      catch (error) {
        alert(error)
      }
    }
  }
  registrationPage() {
    this.router.navigate(['registrationPage']);
  }
}
