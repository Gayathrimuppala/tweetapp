export class Auth {
    firstName: String;
    lastName: String;
    gender: String;
    dob: Date;
    email: String;
    password: String;
}