import { User } from "./login-model";
export class AllTweet {
    tweets: Tweets[];
    success: boolean;
    message: String;
    errorMessage: String
}
export class Tweet {
    id: number;
    tweet: String;
}

export class Tweets {
    firstName: String;
    userTweet: Tweet;
}
export class MyTweets
{
    id:Number;
    firstName:string;
    email:string;
    message:string;
    tweets: Tweets[];

}
export class PostTweet
{
    tweet:string;
    user: User = new User();
}