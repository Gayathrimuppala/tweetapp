export class UserList
{
    email:string;
    firstName:string;
    lastName:string;
    dob:string;
    gender:string;
}
export class ForgotPasswordDetails
{
    securityQuestion: string;
    answer: string;
    email:string;
    password:string;
}