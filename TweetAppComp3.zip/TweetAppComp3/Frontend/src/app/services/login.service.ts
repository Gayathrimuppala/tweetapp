import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from './../../environments/environment';

import { AuthenticateUser, RegisterUser, ChangePassword } from '../models/login-model';
const headerValues = {
  'Authorization': 'Bearer ' + localStorage.getItem('token')
}

@Injectable({ providedIn: 'root' })
export class LoginService {
  public user: Observable<any>;


  constructor(
    public router: Router,
    public http: HttpClient,
  ) { }


  public AuthenticateUser(_authenticateUser: AuthenticateUser): Observable<any> {

    return this.http.post(environment.apiUrl + "/tweetapp/user/login", _authenticateUser, { observe: 'response' });

  }


  public RegisterUser(_registerUser: RegisterUser): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user",
      _registerUser);
  }

  public LogoutUser(id: number): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/logout/" + id, {
      headers: headerValues
    });
  }
  public ChangePassword(_changePassword: ChangePassword): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user/reset", _changePassword, {
      headers: headerValues
    });
  }
  public getSecurityQuestion(email: string): Observable<any> {
    return this.http.get(environment.apiUrl + "/tweetapp/user/forgotPassword/" + email, {
      headers: headerValues
    });
  }

  public forgotPassword(forgotPasswordDetails: any): Observable<any> {
    return this.http.post(environment.apiUrl + "/tweetapp/user/forgotPassword/", forgotPasswordDetails, {
      headers: headerValues
    });
  }



}
