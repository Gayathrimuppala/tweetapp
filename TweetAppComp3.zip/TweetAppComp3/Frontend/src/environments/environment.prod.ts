export const environment = {
  production: true,
  apiUrl: 'http://18.118.101.211:8081',
};
