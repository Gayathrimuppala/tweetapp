package com.tweet.app.constants;

public class BatchConstants {

	public static final String DOB_FORMAT = "yyyy/MM/dd";
	
	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String URL = "jdbc:mysql://localhost:3306/tweet";
	public static final String SQL_USER = "root";
	public static final String SQL_PASSWORD = "root";
	
	public static final String GET_ALL_TWEETS = "SELECT message FROM post ";
	public static final String GET_USER_TWEETS = "SELECT message FROM post WHERE us_email = ? ";	
	public static final String SAVE_TWEET = "INSERT INTO post(message,us_email)values(?,?)";

	public static final String SAVE_USER = "INSERT INTO user (`us_f_name`, `us_l_name`, `us_gender`, `us_dob`, `us_email`, `us_password`)  VALUES (?,?,?,?,?,?)";
	public static final String GET_USER = "SELECT us_email, us_password from user where us_email = ?";	
		

}